#include "LlistaIOEstudiant.hh"

void llegir_llista_Estudiant(list<Estudiant>& l){
    list<Estudiant>::iterator it = l.end();
    Estudiant x;
    x.llegir();
    while (x.consultar_DNI() != 0 or x.consultar_nota() != 0) {
        l.insert(it, x);
        x.llegir();
    }
}

void escriure_llista_Estudiant(const list<Estudiant>& l) {
    if (not l.empty()) {
        list<Estudiant>::const_iterator it;
        cout << "[Primero]" << endl;
        for (it = l.begin(); it != l.end(); ++it){
            cout << (*it).consultar_DNI() << " " << (*it).consultar_nota() << endl;
        }
        cout << "[Ultimo]";
    } 
    cout << endl;
}
