var searchData=
[
  ['conj_5fcategories_61',['Conj_Categories',['../class_conj___categories.html',1,'']]],
  ['conjunt_5ftornejos_62',['Conjunt_Tornejos',['../class_conjunt___tornejos.html',1,'']]]
];
