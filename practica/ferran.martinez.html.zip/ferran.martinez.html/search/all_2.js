var searchData=
[
  ['canviar_5festat_18',['canviar_estat',['../class_torneig.html#a2dc68c506560a001c250d7fc4997be06',1,'Torneig']]],
  ['categoria_19',['categoria',['../class_conjunt___tornejos.html#a972753b1b9867b6987db9cfdaad314e3',1,'Conjunt_Tornejos']]],
  ['conj_5fcategories_20',['Conj_Categories',['../class_conj___categories.html',1,'Conj_Categories'],['../class_conj___categories.html#ad698ae0749c25a6618bbb327fba78808',1,'Conj_Categories::Conj_Categories()'],['../class_conj___categories.html#aba1c2a79a79eda69e05e4ab785ce97ec',1,'Conj_Categories::Conj_Categories(int c, int k)']]],
  ['conjunt_5fcategories_2ehh_21',['Conjunt_Categories.hh',['../_conjunt___categories_8hh.html',1,'']]],
  ['conjunt_5ftornejos_22',['Conjunt_Tornejos',['../class_conjunt___tornejos.html',1,'Conjunt_Tornejos'],['../class_conjunt___tornejos.html#a3bdbea6ac373fbfaa32fd270eafa9d12',1,'Conjunt_Tornejos::Conjunt_Tornejos()'],['../class_conjunt___tornejos.html#afbdd03e520ad6b7043bf05955b6b095f',1,'Conjunt_Tornejos::Conjunt_Tornejos(int num_tjs)']]],
  ['conjunt_5ftornejos_2ehh_23',['Conjunt_Tornejos.hh',['../_conjunt___tornejos_8hh.html',1,'']]],
  ['consultar_5fcategoria_24',['consultar_categoria',['../class_torneig.html#a78a82b011e01b5d07ade6378da916c3c',1,'Torneig']]],
  ['consultar_5festat_25',['consultar_estat',['../class_torneig.html#a94613daf92f04e676a6c606894be56df',1,'Torneig']]],
  ['consultar_5fnom_26',['consultar_nom',['../class_torneig.html#a1a7fbad38abbfd0bb42b0116ffa67524',1,'Torneig']]]
];
