var searchData=
[
  ['pràctica_20de_20pro2_3a_20especificació_20de_20la_20pràctica_2e_46',['Pràctica de PRO2: Especificació de la pràctica.',['../index.html',1,'']]],
  ['punts_47',['punts',['../struct_tg.html#a9afea82835ed77bc0650ed8ba8b4f70d',1,'Tg::punts()'],['../class_conj___categories.html#a7cebfe4f6e7e47e7dd826aa954606b84',1,'Conj_Categories::punts()']]]
];
