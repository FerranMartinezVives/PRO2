var searchData=
[
  ['actualitzar_5franking_0',['actualitzar_ranking',['../class_ranking.html#a124c5ea84e3702119b743e3accf8d109',1,'Ranking']]],
  ['afegir_5ftorneig_1',['afegir_torneig',['../class_jugador.html#ae640325f4322481f998813d169fddb0a',1,'Jugador::afegir_torneig()'],['../class_ranking.html#a70e2a51bf131daa5dbd2bba9aac96637',1,'Ranking::afegir_torneig()']]],
  ['alta_5fjugador_2',['alta_jugador',['../class_ranking.html#a0e8716827ec6442dadc6d53bb4dc3ab3',1,'Ranking']]],
  ['alta_5ftorneig_3',['alta_torneig',['../class_conjunt___tornejos.html#a4da630471c1c4d27b532686a79114a21',1,'Conjunt_Tornejos']]],
  ['augmentar_5fj_5fg_4',['augmentar_j_g',['../class_jugador.html#a519239013f08f8feb87e39271ad44f01',1,'Jugador']]],
  ['augmentar_5fj_5fp_5',['augmentar_j_p',['../class_jugador.html#a5bfeeb4a4cfad279eaa40ba2794f78c4',1,'Jugador']]],
  ['augmentar_5fp_5fg_6',['augmentar_p_g',['../class_jugador.html#a74a050b7e634c19daf9547c834c9bccd',1,'Jugador']]],
  ['augmentar_5fp_5fp_7',['augmentar_p_p',['../class_jugador.html#a733764090dfe189b136d61253d9036c1',1,'Jugador']]],
  ['augmentar_5fs_5fg_8',['augmentar_s_g',['../class_jugador.html#af68b8164ae4d4db80c45c57c2393143b',1,'Jugador']]],
  ['augmentar_5fs_5fp_9',['augmentar_s_p',['../class_jugador.html#aa88f7e917d004b0e392f18c00c17401e',1,'Jugador']]],
  ['augmentar_5ft_5fd_10',['augmentar_t_d',['../class_jugador.html#a92d94b10f1fd7afc3d46c0e75ddf253d',1,'Jugador']]]
];
