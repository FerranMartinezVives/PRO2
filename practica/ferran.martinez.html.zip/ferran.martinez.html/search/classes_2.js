var searchData=
[
  ['jugador_63',['Jugador',['../class_jugador.html',1,'']]]
];
