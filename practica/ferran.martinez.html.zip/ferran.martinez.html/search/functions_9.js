var searchData=
[
  ['punts_114',['punts',['../class_conj___categories.html#a7cebfe4f6e7e47e7dd826aa954606b84',1,'Conj_Categories']]]
];
