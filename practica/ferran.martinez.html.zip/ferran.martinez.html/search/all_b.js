var searchData=
[
  ['ranking_48',['Ranking',['../class_ranking.html',1,'Ranking'],['../class_ranking.html#a7b1142b455d06f3d455d796ed329118f',1,'Ranking::Ranking()'],['../class_ranking.html#a9b1dfbeee361b0ae4a55d9ce401d1dd4',1,'Ranking::Ranking(int num_jgds, const list&lt; string &gt; &amp;tornejos)']]],
  ['ranking_2ehh_49',['Ranking.hh',['../_ranking_8hh.html',1,'']]],
  ['right_50',['right',['../class_bin_tree.html#aff8e96651b27284c329667b5ad3e4d0b',1,'BinTree']]]
];
