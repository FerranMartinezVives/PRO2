var indexSectionsWithContent =
{
  0: "abcefijlmnprtv~",
  1: "bcjrt",
  2: "bcjmrt",
  3: "abcefijlmprtv~",
  4: "np",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables",
  5: "Pàgines"
};

