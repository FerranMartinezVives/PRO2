var searchData=
[
  ['eliminar_5ftorneig_98',['eliminar_torneig',['../class_jugador.html#af8718bb937105bf0baafce15029d4d38',1,'Jugador::eliminar_torneig()'],['../class_ranking.html#a255d86f5886087cc553a090f8beaa9df',1,'Ranking::eliminar_torneig()']]],
  ['empty_99',['empty',['../class_bin_tree.html#a74cda259ba5c25b8ee38ed4dc33e4fad',1,'BinTree']]]
];
