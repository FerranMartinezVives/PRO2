var searchData=
[
  ['imprimeix_5fcategories_30',['imprimeix_categories',['../class_conj___categories.html#a72edaa4af121256da492dcb6d9f5b29d',1,'Conj_Categories']]],
  ['imprimeix_5femparellaments_31',['imprimeix_emparellaments',['../class_conjunt___tornejos.html#a83b6ed8a64b78b166ec6b7b455a2037c',1,'Conjunt_Tornejos']]],
  ['imprimeix_5fjugador_32',['imprimeix_jugador',['../class_ranking.html#a4472913642c2acaced971e15c7ea83fc',1,'Ranking']]],
  ['imprimeix_5fjugadors_33',['imprimeix_jugadors',['../class_ranking.html#a9bf1ea8615dedd1cfa9ab820454df01d',1,'Ranking']]],
  ['imprimeix_5franking_34',['imprimeix_ranking',['../class_jugador.html#a72d3d855ec384960b671034bab0cc0e4',1,'Jugador::imprimeix_ranking()'],['../class_ranking.html#a7f68c4f16408337d955063e16d4c18f8',1,'Ranking::imprimeix_ranking()']]],
  ['imprimeix_5ftot_35',['imprimeix_tot',['../class_jugador.html#a43115d2f55874b3bde017abc2f6961f7',1,'Jugador']]],
  ['imprimeix_5ftour_36',['imprimeix_tour',['../class_conjunt___tornejos.html#a60b4b58f208b766f6e1fbe4845f35dba',1,'Conjunt_Tornejos']]]
];
