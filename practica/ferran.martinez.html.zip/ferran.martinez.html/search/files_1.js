var searchData=
[
  ['conjunt_5fcategories_2ehh_68',['Conjunt_Categories.hh',['../_conjunt___categories_8hh.html',1,'']]],
  ['conjunt_5ftornejos_2ehh_69',['Conjunt_Tornejos.hh',['../_conjunt___tornejos_8hh.html',1,'']]]
];
