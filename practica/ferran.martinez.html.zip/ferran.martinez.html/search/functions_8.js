var searchData=
[
  ['main_112',['main',['../main_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cc']]],
  ['modificar_5fpuntuacio_113',['modificar_puntuacio',['../class_jugador.html#a0fbfdfa62f03f5d37253bcabb57525b8',1,'Jugador']]]
];
