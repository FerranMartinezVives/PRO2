var searchData=
[
  ['punts_125',['punts',['../struct_tg.html#a9afea82835ed77bc0650ed8ba8b4f70d',1,'Tg']]]
];
