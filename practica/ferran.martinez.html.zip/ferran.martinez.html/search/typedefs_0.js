var searchData=
[
  ['matriu_114',['Matriu',['../_conjunt___categories_8hh.html#ab7c37ab727b1a10ad22235f76cfb5ecc',1,'Conjunt_Categories.hh']]]
];
