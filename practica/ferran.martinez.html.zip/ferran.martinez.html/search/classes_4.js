var searchData=
[
  ['tg_65',['Tg',['../struct_tg.html',1,'']]],
  ['torneig_66',['Torneig',['../class_torneig.html',1,'']]]
];
