var searchData=
[
  ['finalitzar_5ftorneig_100',['finalitzar_torneig',['../class_conjunt___tornejos.html#ad01bb494f32ea74e444cff7b368f454c',1,'Conjunt_Tornejos']]]
];
