var searchData=
[
  ['main_42',['main',['../main_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cc']]],
  ['main_2ecc_43',['main.cc',['../main_8cc.html',1,'']]],
  ['modificar_5fpuntuacio_44',['modificar_puntuacio',['../class_jugador.html#a0fbfdfa62f03f5d37253bcabb57525b8',1,'Jugador']]]
];
