var searchData=
[
  ['jugador_37',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a1d2b78a3df59b428d00f30e4c9461e8b',1,'Jugador::Jugador(const string &amp;n, const list&lt; string &gt; &amp;tornejos)']]],
  ['jugador_2ehh_38',['Jugador.hh',['../_jugador_8hh.html',1,'']]]
];
