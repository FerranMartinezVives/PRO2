var searchData=
[
  ['pràctica_20de_20pro2_3a_20especificació_20de_20la_20pràctica_2e_126',['Pràctica de PRO2: Especificació de la pràctica.',['../index.html',1,'']]]
];
