var searchData=
[
  ['tg_51',['Tg',['../struct_tg.html',1,'']]],
  ['torneig_52',['Torneig',['../class_torneig.html',1,'Torneig'],['../class_torneig.html#a833b2f486a1648a8741d2115a9bb186c',1,'Torneig::Torneig()'],['../class_torneig.html#ac8d44f64cc47a618741d7637409374fc',1,'Torneig::Torneig(const string &amp;t, int c)']]],
  ['torneig_2ehh_53',['Torneig.hh',['../_torneig_8hh.html',1,'']]]
];
