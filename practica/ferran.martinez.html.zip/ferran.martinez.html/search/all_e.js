var searchData=
[
  ['_7econj_5fcategories_55',['~Conj_Categories',['../class_conj___categories.html#a3c1f4656321d9fd56124eb2f24bbff58',1,'Conj_Categories']]],
  ['_7econjunt_5ftornejos_56',['~Conjunt_Tornejos',['../class_conjunt___tornejos.html#a31ed43e52e40ef1605b5018c81e46b28',1,'Conjunt_Tornejos']]],
  ['_7ejugador_57',['~Jugador',['../class_jugador.html#a9db1d422fe3b675f92d9fd687b1f42c4',1,'Jugador']]],
  ['_7eranking_58',['~Ranking',['../class_ranking.html#aa350c65acea82ec0ac42ec80db8bc00f',1,'Ranking']]],
  ['_7etorneig_59',['~Torneig',['../class_torneig.html#ab5184085575669dd522e11a25f602943',1,'Torneig']]]
];
