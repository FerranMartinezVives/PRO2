var searchData=
[
  ['left_39',['left',['../class_bin_tree.html#a82108db4c1b08d1f111027788c196d4e',1,'BinTree']]],
  ['llista_5finscripcions_40',['llista_inscripcions',['../class_ranking.html#aea385ffd5e58d6d1fb0e2f790367b4dd',1,'Ranking']]],
  ['llistar_5ftornejos_41',['llistar_tornejos',['../class_conjunt___tornejos.html#a16ea053304ee506432ce087ed5d2d415',1,'Conjunt_Tornejos']]]
];
