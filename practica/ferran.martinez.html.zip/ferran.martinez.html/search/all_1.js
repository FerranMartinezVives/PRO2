var searchData=
[
  ['baixa_5fjugador_11',['baixa_jugador',['../class_ranking.html#a89629015f9378cd5b251bb620f964e30',1,'Ranking']]],
  ['baixa_5ftorneig_12',['baixa_torneig',['../class_conjunt___tornejos.html#a1d771eccbd52736e8fd84e3d0b11451c',1,'Conjunt_Tornejos']]],
  ['bintree_13',['BinTree',['../class_bin_tree.html',1,'BinTree&lt; T &gt;'],['../class_bin_tree.html#a47eef22d29cd023449d97c073c08e5b6',1,'BinTree::BinTree()'],['../class_bin_tree.html#a1ab686e0bcf990093ff91fe71744c1a4',1,'BinTree::BinTree(const T &amp;x)'],['../class_bin_tree.html#adb7eeff76d08130c943b36af215eb521',1,'BinTree::BinTree(const T &amp;x, const BinTree &amp;left, const BinTree &amp;right)']]],
  ['bintree_2ehh_14',['BinTree.hh',['../_bin_tree_8hh.html',1,'']]],
  ['buscar_5fiterador_15',['buscar_iterador',['../class_conjunt___tornejos.html#a1ce15b0b0566220da46c8d25c37815fb',1,'Conjunt_Tornejos::buscar_iterador()'],['../class_ranking.html#a36c978c4f27bb82ee8a20dbab4420985',1,'Ranking::buscar_iterador()']]],
  ['buscar_5fjugador_16',['buscar_jugador',['../class_ranking.html#aa2bfabe4d132f78dc81c5ce67df7f01a',1,'Ranking']]],
  ['buscar_5ftorneig_17',['buscar_torneig',['../class_conjunt___tornejos.html#abc9140532a73a2f1faacffcd3037e0f2',1,'Conjunt_Tornejos']]]
];
