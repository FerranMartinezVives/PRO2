var searchData=
[
  ['jugador_172',['Jugador',['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a1990d7f990f90c517c7868ce45e2b85f',1,'Jugador::Jugador(const string &amp;n)']]]
];
