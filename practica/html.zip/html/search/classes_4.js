var searchData=
[
  ['torneig_109',['Torneig',['../class_torneig.html',1,'']]]
];
