var searchData=
[
  ['partit_107',['Partit',['../class_partit.html',1,'']]]
];
