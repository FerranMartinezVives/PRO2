var searchData=
[
  ['nom_70',['nom',['../class_jugador.html#afd6bec98df8ebb3d2db3ef583a76cfa1',1,'Jugador::nom()'],['../class_torneig.html#a803fb4b7e0637c93229eb562a280c681',1,'Torneig::nom()']]],
  ['num_5fctgs_71',['num_ctgs',['../class_conjunt___categories.html#ad384d6e42b9b73a1bfbcdf399e3f4fac',1,'Conjunt_Categories']]],
  ['num_5fnvls_72',['num_nvls',['../class_conjunt___categories.html#a8858bf3774c198c452f57e373a8df3ad',1,'Conjunt_Categories']]]
];
