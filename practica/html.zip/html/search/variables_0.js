var searchData=
[
  ['a_191',['a',['../class_partit.html#a62e058b04085e59ae88ef25e420335e6',1,'Partit']]],
  ['actuals_192',['actuals',['../class_torneig.html#a28184b87f1083e260a2fb3bfe4ee9322',1,'Torneig']]],
  ['anteriors_193',['anteriors',['../class_torneig.html#a61f47d179ec9b201c312c192d9bf96cc',1,'Torneig']]]
];
