var searchData=
[
  ['torneig_183',['Torneig',['../class_torneig.html#a833b2f486a1648a8741d2115a9bb186c',1,'Torneig::Torneig()'],['../class_torneig.html#ac8d44f64cc47a618741d7637409374fc',1,'Torneig::Torneig(const string &amp;t, int c)']]]
];
