var searchData=
[
  ['conjunt_5fcategories_138',['Conjunt_Categories',['../class_conjunt___categories.html#a05261dde4c31db773c1f9748022a076b',1,'Conjunt_Categories::Conjunt_Categories()'],['../class_conjunt___categories.html#a5b346e106e4b325557918cb04eaf213f',1,'Conjunt_Categories::Conjunt_Categories(int c, int k)']]],
  ['conjunt_5ftornejos_139',['Conjunt_Tornejos',['../class_conjunt___tornejos.html#a3bdbea6ac373fbfaa32fd270eafa9d12',1,'Conjunt_Tornejos::Conjunt_Tornejos()'],['../class_conjunt___tornejos.html#afbdd03e520ad6b7043bf05955b6b095f',1,'Conjunt_Tornejos::Conjunt_Tornejos(int num_tjs)']]],
  ['consultar_5fa_140',['consultar_a',['../class_partit.html#a7132df3dd0d6234f08b5bf1255b551cd',1,'Partit']]],
  ['consultar_5fb_141',['consultar_b',['../class_partit.html#ac3cf7cc67eefedb85b46e0768b593c0c',1,'Partit']]],
  ['consultar_5fcategoria_142',['consultar_categoria',['../class_conjunt___tornejos.html#a2a3dda18fc3f0f23fa767bd91c368ad9',1,'Conjunt_Tornejos::consultar_categoria()'],['../class_torneig.html#a78a82b011e01b5d07ade6378da916c3c',1,'Torneig::consultar_categoria()']]],
  ['consultar_5fguanyador_143',['consultar_guanyador',['../class_partit.html#adea8daef3cf1174c0e824a84b6eb8389',1,'Partit']]],
  ['consultar_5fjocs_5fa_144',['consultar_jocs_a',['../class_partit.html#a1ead80fd4291342fd34bd960911e0919',1,'Partit']]],
  ['consultar_5fjocs_5fb_145',['consultar_jocs_b',['../class_partit.html#a3f0f54c93ff85554e2b92d72135a75bf',1,'Partit']]],
  ['consultar_5fnom_146',['consultar_nom',['../class_conjunt___categories.html#a5caaadc0c034701e27c5231c2491f7f7',1,'Conjunt_Categories::consultar_nom()'],['../class_jugador.html#a44796353316adc3821484969c75f9457',1,'Jugador::consultar_nom()'],['../class_torneig.html#a1a7fbad38abbfd0bb42b0116ffa67524',1,'Torneig::consultar_nom()']]],
  ['consultar_5fpartits_5fa_147',['consultar_partits_a',['../class_partit.html#ad68b13af9d7f165c550cc8b119a74864',1,'Partit']]],
  ['consultar_5fpartits_5fb_148',['consultar_partits_b',['../class_partit.html#adfec3094149e91b2ab64ce03b1284081',1,'Partit']]],
  ['consultar_5fperdedor_149',['consultar_perdedor',['../class_partit.html#ad06770cba0f499d5dd598b6dd1a047b6',1,'Partit']]],
  ['consultar_5fpuntuacio_150',['consultar_puntuacio',['../class_jugador.html#a44953936a0ebb083f5ca456d1085461b',1,'Jugador']]],
  ['consultar_5fresultats_151',['consultar_resultats',['../class_partit.html#aa07406d615f8d304a4aa4b0fe1a054b5',1,'Partit']]],
  ['consultar_5fsets_5fa_152',['consultar_sets_a',['../class_partit.html#a2d6533b71e6a7fd7d20ebece14347f96',1,'Partit']]],
  ['consultar_5fsets_5fb_153',['consultar_sets_b',['../class_partit.html#a2597f4f0d8827e67c18dd258ce5450ec',1,'Partit']]]
];
