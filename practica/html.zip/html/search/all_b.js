var searchData=
[
  ['ordenar_5franking_73',['ordenar_ranking',['../class_ranking.html#ab00377801bf2969af81146c2a050f6fb',1,'Ranking']]],
  ['ordre_5franking_74',['ordre_ranking',['../class_ranking.html#a6e33f856ed64f8b0a27338f7f54d647b',1,'Ranking']]]
];
