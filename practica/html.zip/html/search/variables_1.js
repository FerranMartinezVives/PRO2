var searchData=
[
  ['b_194',['b',['../class_partit.html#af33dc3dac6db87d5374be25c4919772a',1,'Partit']]]
];
