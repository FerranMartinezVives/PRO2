var searchData=
[
  ['emparellaments_197',['emparellaments',['../class_torneig.html#acfe3b9b6715936ffb48d7afb59dc5cd3',1,'Torneig']]]
];
