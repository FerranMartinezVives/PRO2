var searchData=
[
  ['conjunt_5fcategories_104',['Conjunt_Categories',['../class_conjunt___categories.html',1,'']]],
  ['conjunt_5ftornejos_105',['Conjunt_Tornejos',['../class_conjunt___tornejos.html',1,'']]]
];
