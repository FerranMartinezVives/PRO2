var searchData=
[
  ['ranking_182',['Ranking',['../class_ranking.html#a7b1142b455d06f3d455d796ed329118f',1,'Ranking::Ranking()'],['../class_ranking.html#a1639f112b48967caf38e1ab4be57b203',1,'Ranking::Ranking(int num_jgds)']]]
];
