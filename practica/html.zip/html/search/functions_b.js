var searchData=
[
  ['partit_180',['Partit',['../class_partit.html#a80beaa342d3415e7bfc33319dbe302bf',1,'Partit::Partit()'],['../class_partit.html#aee6691b56de92ac767b692070bd69523',1,'Partit::Partit(const string &amp;s)']]],
  ['punts_181',['punts',['../class_conjunt___categories.html#ac64ebe321accf18f49f51cc98660c5a9',1,'Conjunt_Categories']]]
];
