var indexSectionsWithContent =
{
  0: "abcefgijlmnoprstu~",
  1: "cjprt",
  2: "cjprt",
  3: "abcefgijmnoprtu~",
  4: "abcejlnprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables"
};

