var searchData=
[
  ['s_5fa_209',['s_a',['../class_partit.html#a38df6dac4eaf46e401f6eb82a1eb86e4',1,'Partit']]],
  ['s_5fb_210',['s_b',['../class_partit.html#af7aab16150fd3dde261fd0e988d62a11',1,'Partit']]],
  ['sets_211',['sets',['../class_jugador.html#a0f820a9a62c75c9104ac759c48a2219b',1,'Jugador']]]
];
