var searchData=
[
  ['generar_5farbre_5femparellaments_48',['generar_arbre_emparellaments',['../class_torneig.html#a90da44a39073127150c33fee1bfaea52',1,'Torneig']]],
  ['generar_5farbre_5fresultats_49',['generar_arbre_resultats',['../class_torneig.html#abdc67d1eecc2b9cf71c62a05f9152f30',1,'Torneig']]]
];
