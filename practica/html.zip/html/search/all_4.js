var searchData=
[
  ['finalitzar_46',['finalitzar',['../class_torneig.html#a47302c658bb20065ea4af776fd1873cc',1,'Torneig']]],
  ['finalitzar_5ftorneig_47',['finalitzar_torneig',['../class_conjunt___tornejos.html#a92f32d1b9dd02d321426b16abd82c6c8',1,'Conjunt_Tornejos']]]
];
