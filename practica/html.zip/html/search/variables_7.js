var searchData=
[
  ['p_5fa_203',['p_a',['../class_partit.html#a5e0d317c9b8033dd63dca369e8e9c645',1,'Partit']]],
  ['p_5fb_204',['p_b',['../class_partit.html#a77f70e22c523792690445a8467213b48',1,'Partit']]],
  ['partits_205',['partits',['../class_jugador.html#a8f0f11e039b0a26a218ae4240f93299d',1,'Jugador']]],
  ['puntuacio_206',['puntuacio',['../class_jugador.html#ac7c0a3cc519b63d3f81fc1af8f6d1e7d',1,'Jugador']]]
];
