var searchData=
[
  ['ranking_207',['ranking',['../class_ranking.html#ab63addb21d82ffcbbf89ff1ed4927054',1,'Ranking']]],
  ['resultats_208',['resultats',['../class_partit.html#a3d25d4ef01c7047872c33d055b471309',1,'Partit']]]
];
