var searchData=
[
  ['emparellaments_41',['emparellaments',['../class_torneig.html#acfe3b9b6715936ffb48d7afb59dc5cd3',1,'Torneig']]],
  ['esborrar_5fjugador_42',['esborrar_jugador',['../class_torneig.html#a6ef01919aa6de633cbf6355434b28f09',1,'Torneig']]],
  ['esborrar_5fpunts_43',['esborrar_punts',['../class_torneig.html#a5aca4a5b43447006da75253c35b6740b',1,'Torneig']]],
  ['escriure_5fa_44',['escriure_a',['../class_partit.html#a9076cd635c0f8199d855560f92122572',1,'Partit']]],
  ['escriure_5fb_45',['escriure_b',['../class_partit.html#a4042774952fdf21a6aaae486dd7f9570',1,'Partit']]]
];
