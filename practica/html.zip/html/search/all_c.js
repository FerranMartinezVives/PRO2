var searchData=
[
  ['p_5fa_75',['p_a',['../class_partit.html#a5e0d317c9b8033dd63dca369e8e9c645',1,'Partit']]],
  ['p_5fb_76',['p_b',['../class_partit.html#a77f70e22c523792690445a8467213b48',1,'Partit']]],
  ['partit_77',['Partit',['../class_partit.html',1,'Partit'],['../class_partit.html#a80beaa342d3415e7bfc33319dbe302bf',1,'Partit::Partit()'],['../class_partit.html#aee6691b56de92ac767b692070bd69523',1,'Partit::Partit(const string &amp;s)']]],
  ['partit_2ecc_78',['Partit.cc',['../_partit_8cc.html',1,'']]],
  ['partit_2ehh_79',['Partit.hh',['../_partit_8hh.html',1,'']]],
  ['partits_80',['partits',['../class_jugador.html#a8f0f11e039b0a26a218ae4240f93299d',1,'Jugador']]],
  ['program_2ecc_81',['program.cc',['../program_8cc.html',1,'']]],
  ['punts_82',['punts',['../class_conjunt___categories.html#ac64ebe321accf18f49f51cc98660c5a9',1,'Conjunt_Categories']]],
  ['puntuacio_83',['puntuacio',['../class_jugador.html#ac7c0a3cc519b63d3f81fc1af8f6d1e7d',1,'Jugador']]]
];
