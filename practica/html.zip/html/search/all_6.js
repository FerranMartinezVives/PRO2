var searchData=
[
  ['imprimeix_5fcategories_50',['imprimeix_categories',['../class_conjunt___categories.html#ab49139706e0a5ca6142873522502098a',1,'Conjunt_Categories']]],
  ['imprimeix_5festadistiques_51',['imprimeix_estadistiques',['../class_jugador.html#a310a8fbf173a2d02fead59ffecbb80fd',1,'Jugador']]],
  ['imprimeix_5fjugador_52',['imprimeix_jugador',['../class_ranking.html#a5484f780b1d031a64bcce44d7cb6a768',1,'Ranking']]],
  ['imprimeix_5fjugadors_53',['imprimeix_jugadors',['../class_ranking.html#a9bf1ea8615dedd1cfa9ab820454df01d',1,'Ranking']]],
  ['imprimeix_5franking_54',['imprimeix_ranking',['../class_ranking.html#a7f68c4f16408337d955063e16d4c18f8',1,'Ranking']]],
  ['imprimeix_5ftour_55',['imprimeix_tour',['../class_conjunt___tornejos.html#a20f54606fb875daba163708a78454487',1,'Conjunt_Tornejos']]],
  ['imprimir_5farbre_5femparellaments_56',['imprimir_arbre_emparellaments',['../class_torneig.html#af3f285b83eb4935aa3bf6dd685f2ce1d',1,'Torneig']]],
  ['imprimir_5farbre_5fresultats_57',['imprimir_arbre_resultats',['../class_torneig.html#adb4208da96306154a2e56aa4f23310d9',1,'Torneig']]],
  ['iniciar_58',['iniciar',['../class_torneig.html#a4d25a02f9aef1a5e27041b6d9f909c35',1,'Torneig']]],
  ['iniciar_5ftorneig_59',['iniciar_torneig',['../class_conjunt___tornejos.html#a7e92eb7b12ffc8aec96ec9793c889068',1,'Conjunt_Tornejos']]]
];
