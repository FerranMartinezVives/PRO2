var searchData=
[
  ['taula_5fpunts_91',['taula_punts',['../class_conjunt___categories.html#af7422780f5da5187fb15cc6597eb0ee7',1,'Conjunt_Categories']]],
  ['torneig_92',['Torneig',['../class_torneig.html',1,'Torneig'],['../class_torneig.html#a833b2f486a1648a8741d2115a9bb186c',1,'Torneig::Torneig()'],['../class_torneig.html#ac8d44f64cc47a618741d7637409374fc',1,'Torneig::Torneig(const string &amp;t, int c)']]],
  ['torneig_2ecc_93',['Torneig.cc',['../_torneig_8cc.html',1,'']]],
  ['torneig_2ehh_94',['Torneig.hh',['../_torneig_8hh.html',1,'']]],
  ['tornejos_5fdisputats_95',['tornejos_disputats',['../class_jugador.html#a32623d8c3cacd4cbbd0c926eb14cfd8e',1,'Jugador']]],
  ['tour_96',['tour',['../class_conjunt___tornejos.html#a429aa696a3e831505e8641e7e9331643',1,'Conjunt_Tornejos']]]
];
