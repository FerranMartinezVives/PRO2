var searchData=
[
  ['cat_195',['cat',['../class_torneig.html#af906434d135fe60c7677e3e638b9fe94',1,'Torneig']]],
  ['categories_196',['categories',['../class_conjunt___categories.html#a8ce832dd623f582a67c6b1afd0cf9657',1,'Conjunt_Categories']]]
];
