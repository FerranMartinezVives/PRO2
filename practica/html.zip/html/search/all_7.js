var searchData=
[
  ['j_5fa_60',['j_a',['../class_partit.html#a23d650178a77cba286cf6dd2062a350e',1,'Partit']]],
  ['j_5fb_61',['j_b',['../class_partit.html#ab17b1ef4e068e8c64fd1026d2f96572a',1,'Partit']]],
  ['jocs_62',['jocs',['../class_jugador.html#aed10dfe9a59ccb5fc7092828398aa75f',1,'Jugador']]],
  ['jugador_63',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a1990d7f990f90c517c7868ce45e2b85f',1,'Jugador::Jugador(const string &amp;n)']]],
  ['jugador_2ecc_64',['Jugador.cc',['../_jugador_8cc.html',1,'']]],
  ['jugador_2ehh_65',['Jugador.hh',['../_jugador_8hh.html',1,'']]]
];
