var searchData=
[
  ['upset_97',['upset',['../class_partit.html#a7731fc3c7726bbea064e86177c694d6b',1,'Partit']]]
];
