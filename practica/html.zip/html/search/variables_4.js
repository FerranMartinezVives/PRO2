var searchData=
[
  ['j_5fa_198',['j_a',['../class_partit.html#a23d650178a77cba286cf6dd2062a350e',1,'Partit']]],
  ['j_5fb_199',['j_b',['../class_partit.html#ab17b1ef4e068e8c64fd1026d2f96572a',1,'Partit']]],
  ['jocs_200',['jocs',['../class_jugador.html#aed10dfe9a59ccb5fc7092828398aa75f',1,'Jugador']]]
];
