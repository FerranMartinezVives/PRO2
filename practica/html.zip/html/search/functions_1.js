var searchData=
[
  ['baixa_5fjugador_135',['baixa_jugador',['../class_conjunt___tornejos.html#af0fc3ec1eac2df34c21600a46e7da8c9',1,'Conjunt_Tornejos::baixa_jugador()'],['../class_ranking.html#ab63d27dc5a053748c2f39678d4a619c0',1,'Ranking::baixa_jugador()']]],
  ['baixa_5ftorneig_136',['baixa_torneig',['../class_conjunt___tornejos.html#a9c5f2508a5abbd7b3a4b0583f0448209',1,'Conjunt_Tornejos']]],
  ['buscar_5fposicio_137',['buscar_posicio',['../class_ranking.html#a43fcf8beb2a3f1c1714e1ffbf61135e4',1,'Ranking']]]
];
