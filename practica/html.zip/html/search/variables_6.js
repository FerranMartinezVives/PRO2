var searchData=
[
  ['nom_202',['nom',['../class_jugador.html#afd6bec98df8ebb3d2db3ef583a76cfa1',1,'Jugador::nom()'],['../class_torneig.html#a803fb4b7e0637c93229eb562a280c681',1,'Torneig::nom()']]]
];
