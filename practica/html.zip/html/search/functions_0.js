var searchData=
[
  ['actualitzar_5fjocs_123',['actualitzar_jocs',['../class_ranking.html#a7dce29cb261b844884eb41fc4e68556b',1,'Ranking']]],
  ['actualitzar_5fpartits_124',['actualitzar_partits',['../class_ranking.html#a3cafaca9c780db230bf52f87c89c4722',1,'Ranking']]],
  ['actualitzar_5fpunts_125',['actualitzar_punts',['../class_ranking.html#a0655d4f2b9e8db5c2c5bd74197ed5b30',1,'Ranking']]],
  ['actualitzar_5fsets_126',['actualitzar_sets',['../class_ranking.html#a8ae92fc20d1284ed16b8b0f64ec9cc62',1,'Ranking']]],
  ['actualitzar_5ftornejos_127',['actualitzar_tornejos',['../class_ranking.html#a1301d78fa35b7a57c10f890be6a5e724',1,'Ranking']]],
  ['alta_5fjugador_128',['alta_jugador',['../class_ranking.html#a5fb3646eb86e5d01b1f61266e9bbe8c6',1,'Ranking']]],
  ['alta_5ftorneig_129',['alta_torneig',['../class_conjunt___tornejos.html#af5fb7c9cdf4a0b374b998a15a4e2595b',1,'Conjunt_Tornejos']]],
  ['assignar_5fpunts_130',['assignar_punts',['../class_torneig.html#a6d18b81ea9a9a9acec040d095283563e',1,'Torneig']]],
  ['augmentar_5fjocs_131',['augmentar_jocs',['../class_jugador.html#a59fe039c2f1574bdabbc29fe2fce367b',1,'Jugador']]],
  ['augmentar_5fpartits_132',['augmentar_partits',['../class_jugador.html#a87f587ebbbbf499f2069388904b1e2cf',1,'Jugador']]],
  ['augmentar_5fsets_133',['augmentar_sets',['../class_jugador.html#a1a4c026130db92f03a5b4e3227f75293',1,'Jugador']]],
  ['augmentar_5ftornejos_134',['augmentar_tornejos',['../class_jugador.html#a08f4d59b0fdc683d18065510baf12aad',1,'Jugador']]]
];
