var searchData=
[
  ['main_67',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mida_68',['mida',['../class_conjunt___tornejos.html#af00abfef1374b66e8849f1a79a2d2ee1',1,'Conjunt_Tornejos::mida()'],['../class_ranking.html#ab8432ae2eecb7bbb653a94bbe964d32c',1,'Ranking::mida()']]],
  ['modificar_5fpuntuacio_69',['modificar_puntuacio',['../class_jugador.html#aabbe8221c6327757f6ad6131301e3106',1,'Jugador']]]
];
