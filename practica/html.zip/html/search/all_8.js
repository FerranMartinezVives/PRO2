var searchData=
[
  ['llista_66',['llista',['../class_ranking.html#a599ec15f95397565e802ae9d8e144543',1,'Ranking']]]
];
