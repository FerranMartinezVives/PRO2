var searchData=
[
  ['num_5fctgs_176',['num_ctgs',['../class_conjunt___categories.html#ad384d6e42b9b73a1bfbcdf399e3f4fac',1,'Conjunt_Categories']]],
  ['num_5fnvls_177',['num_nvls',['../class_conjunt___categories.html#a8858bf3774c198c452f57e373a8df3ad',1,'Conjunt_Categories']]]
];
