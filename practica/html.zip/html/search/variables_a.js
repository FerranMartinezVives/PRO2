var searchData=
[
  ['taula_5fpunts_212',['taula_punts',['../class_conjunt___categories.html#af7422780f5da5187fb15cc6597eb0ee7',1,'Conjunt_Categories']]],
  ['tornejos_5fdisputats_213',['tornejos_disputats',['../class_jugador.html#a32623d8c3cacd4cbbd0c926eb14cfd8e',1,'Jugador']]],
  ['tour_214',['tour',['../class_conjunt___tornejos.html#a429aa696a3e831505e8641e7e9331643',1,'Conjunt_Tornejos']]]
];
